from figcommon import *
from scipy.optimize import brentq
from scipy.integrate import solve_ivp
# ---------------- Rayleigh distillation
alpha=lambda T:np.exp(1137/T**2-0.4156/T-0.00207)
d0=-13.0
f=np.logspace(0,np.log10(0.02),300)
a0=1.0117
dv=((1+d0/1000)*f**(a0-1)-1)*1000
Lv_Rv=2.5e6/461.5; T0=293.15
Tg=np.linspace(T0,233.15,400)
lnf=-Lv_Rv*(1/Tg-1/T0)
lnR=np.log(1+d0/1000)+np.concatenate([[0],np.cumsum(0.5*((alpha(Tg[1:])-1)+(alpha(Tg[:-1])-1))*np.diff(lnf))])
dvT=(np.exp(lnR)-1)*1000; dc=(alpha(Tg)*np.exp(lnR)-1)*1000
fig,axs=plt.subplots(1,2,figsize=(9.2,3.6))
ax=axs[0]; ax.plot(f,dv,color=BLUE,lw=2)
ax.set_xscale("log"); ax.invert_xaxis(); ax.set_xlabel("fraction of vapour remaining $f$  (more rain-out $\\rightarrow$)"); ax.set_ylabel("$\\delta^{18}$O of remaining vapour (\\textperthousand)".replace("\\textperthousand","‰"))
fp=0.06; ax.plot([fp],[((1+d0/1000)*fp**(a0-1)-1)*1000],"o",color=RED); ax.annotate("$f\\approx0.06$: $\\delta\\approx-45$‰\n(polar vapour, slide 22)",xy=(fp,-45),xytext=(0.5,-40),fontsize=8,arrowprops=dict(arrowstyle="->",color=GREY))
ax.plot([1],[d0],"o",color=GREEN); ax.annotate("start: $-13$‰",xy=(1,d0),xytext=(0.5,-9),fontsize=8,ha="center",va="bottom",arrowprops=dict(arrowstyle="->",color=GREY)); ax.set_ylim(-52,-5); panel(ax,"(a)")
ax=axs[1]; Tc=Tg-273.15; ax.plot(Tc,dc,color=PURPLE,lw=2,label="idealised Rayleigh model")
sl=np.polyfit(Tc[(Tc>-40)&(Tc<20)],dc[(Tc>-40)&(Tc<20)],1)[0]
ref=dc[np.argmin(abs(Tc-0))]; ax.plot(Tc,ref+0.69*(Tc-0),color=GREY,ls="--",lw=1.1,label="slope 0.69 ‰/K (Dansgaard 1964)")
ax.set_xlabel("condensation temperature ($^\\circ$C)"); ax.set_ylabel("$\\delta^{18}$O of precipitation (‰)"); ax.legend(frameon=False,loc="lower right"); panel(ax,"(b)")
fig.tight_layout(w_pad=2.5); fig.savefig("figs/fig_rayleigh.pdf"); plt.close(); print("model slope",sl)

# ---------------- equal area grid
bd=[90,64.158,44.427,23.578,0]; nb=[4,8,12,16]
fig,axs=plt.subplots(1,2,figsize=(9.6,4.0),gridspec_kw={"width_ratios":[1.55,1]})
ax=axs[0]; cols=["#dbe7f5","#c6d9ef","#b1cbe9","#9dbde3"]
edges=[64.158,44.427,23.578,0]
lat_edges=[90,64.158,44.427,23.578,0,-23.578,-44.427,-64.158,-90]; nlist=[4,8,12,16,16,12,8,4]
for i,n in enumerate(nlist):
    y1,y0=lat_edges[i],lat_edges[i+1]
    for j in range(n):
        x0=-180+j*360/n; ax.add_patch(Rectangle((x0,y0),360/n,y1-y0,fc=cols[min(i,7-i)],ec="white",lw=0.9))
    ax.text(186,(y0+y1)/2,f"{n} boxes",va="center",fontsize=8)
for e in lat_edges[1:-1]: ax.text(-184,e,f"{e:.1f}°" if abs(e)>0 else "0°",ha="right",va="center",fontsize=8)
ax.text(-184,90,"90°",ha="right",va="center",fontsize=8); ax.text(-184,-90,"−90°",ha="right",va="center",fontsize=8)
ax.set_xlim(-180,180); ax.set_ylim(-90,90); ax.set_xlabel("longitude"); ax.set_yticks([]); ax.spines["left"].set_visible(False); ax.set_xticks([-180,-90,0,90,180]); ax.set_xticklabels(["−180°","−90°","0°","90°","180°"])
ax.set_title("80 equal-area boxes (Hansen \\& Lebedeff layout)".replace("\\&","&"),fontsize=9.5); panel(ax,"(a)")
ax=axs[1]; ph=np.linspace(0,90,200); ax.plot(ph,np.sin(np.radians(ph)),color=BLUE,lw=2)
for p,lab,dx,dy in [(30,"±30°: 50 % of area",8,-0.09),(64.158,"±64.2°: 90 %",-5,-0.13)]:
    ax.plot([p],[np.sin(np.radians(p))],"o",color=RED); ax.plot([p,p],[0,np.sin(np.radians(p))],color=GREY,ls=":",lw=0.8); ax.plot([0,p],[np.sin(np.radians(p))]*2,color=GREY,ls=":",lw=0.8)
ax.text(33,0.42,"half of the Earth's surface\nlies within $\\pm30^\\circ$",fontsize=8.5,va="top")
ax.text(40,0.97,"90 % within $\\pm64.2^\\circ$",fontsize=8.5,va="bottom")
ax.set_xlabel("latitude bound $\\varphi_0$ (degrees)"); ax.set_ylabel("fraction of area in $|\\varphi|<\\varphi_0$ $=\\sin\\varphi_0$"); ax.set_xlim(0,90); ax.set_ylim(0,1.08); panel(ax,"(b)")
fig.tight_layout(w_pad=3); fig.savefig("figs/fig_grid.pdf"); plt.close()

# ---------------- Planck
lam=np.logspace(-1,2,800)*1e-6
fig,axs=plt.subplots(1,2,figsize=(9.8,3.9),gridspec_kw={"width_ratios":[1.05,1]})
ax=axs[0]
Ts_=[6000,3000,1000,500,288,200]; cm=plt.cm.viridis(np.linspace(0.05,0.85,len(Ts_)))
pk=[]
for T,cc in zip(Ts_,cm):
    B=planck(lam,T)*1e-6; ax.loglog(lam*1e6,B,color=cc,lw=1.6); lm=2.8978e-3/T; pk.append((lm*1e6,planck(lm,T)*1e-6))
    ax.annotate(f"{T} K",xy=(lm*1e6,planck(lm,T)*1e-6),xytext=(4,5),textcoords="offset points",color=cc,fontsize=7.8,ha="left",bbox=dict(fc="white",ec="none",pad=0.6,alpha=0.85))
pk=np.array(pk); ax.loglog(pk[:,0],pk[:,1],color=GREY,ls=":",lw=1,label="Wien locus $\\lambda_m T=b$")
B=2*c*kB*288/lam**4*1e-6; m=lam*1e6>25; ax.loglog(lam[m]*1e6,B[m],color=GREY,ls="--",lw=1,label="Rayleigh–Jeans ($T=288$ K)")
ax.set_ylim(1e-4,1e8); ax.set_xlim(0.1,100); ax.set_xlabel("wavelength $\\lambda$ ($\\mu$m)"); ax.set_ylabel("$B_\\lambda$ (W m$^{-2}$ sr$^{-1}$ $\\mu$m$^{-1}$)"); ax.legend(frameon=False,loc="lower left",fontsize=8); panel(ax,"(a)")
ax=axs[1]
for T,cc,lab in [(6000,ORANGE,"6000 K"),(300,BLUE,"300 K")]:
    B=planck(lam,T); ax.semilogx(lam*1e6,B/B.max(),color=cc,lw=2)
ax.axvspan(0.4,0.7,color="#fff2a8",alpha=0.8,lw=0); ax.axvline(4,color=GREY,ls="--",lw=0.9)
ax.text(0.53,1.03,"visible",ha="center",fontsize=8); ax.text(0.145,0.5,"shortwave\n(solar)",color=ORANGE,fontsize=9,ha="left")
ax.text(30,0.55,"longwave\n(terrestrial)",color=BLUE,fontsize=9,ha="left"); ax.text(4.2,0.93,"4 µm\nseparation",fontsize=8,color=GREY,va="top")
ax.text(0.48,-0.11,"0.48 µm",fontsize=8,ha="center",color=ORANGE); ax.text(9.66,-0.11,"9.7 µm",fontsize=8,ha="center",color=BLUE)
ax.set_xlim(0.1,100); ax.set_ylim(0,1.12); ax.set_xlabel("wavelength $\\lambda$ ($\\mu$m)",labelpad=12); ax.set_ylabel("$B_\\lambda/B_{\\lambda,\\max}$"); panel(ax,"(b)")
fig.tight_layout(w_pad=2.5); fig.savefig("figs/fig_planck.pdf"); plt.close(); print("B done")
