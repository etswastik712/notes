from figcommon import *
from scipy.integrate import solve_ivp
import miepython
# ---- hydrostatic
H=7.5; z=np.linspace(0,30,400)
fig,axs=plt.subplots(1,2,figsize=(9.8,4.0),gridspec_kw={"width_ratios":[1,1.15]})
ax=axs[0]; ax.plot(np.exp(-z/H),z,color=BLUE,lw=2)
zz=np.linspace(0,11,100); ax.fill_betweenx(zz,0,np.exp(-zz/H),color=BLUE,alpha=0.15,lw=0)
ax.plot([np.exp(-1)],[H],"o",color="k",ms=5); ax.annotate("$z=H=7.5$ km:\n$p=p_0/e\\approx0.37\\,p_0$",xy=(np.exp(-1),H),xytext=(0.5,17),fontsize=8.5,arrowprops=dict(arrowstyle="->",color=GREY))
ax.plot([np.exp(-5/H)],[5],"o",color=RED,ms=5); ax.annotate("camp at 5 km:\n$p\\approx0.51\\,p_0\\approx520$ hPa",xy=(np.exp(-5/H),5),xytext=(0.62,2.0),fontsize=8.5,arrowprops=dict(arrowstyle="->",color=GREY))
ax.axhline(11,color=GREY,ls="--",lw=0.8); ax.text(0.98,11.4,"tropopause (11 km)",ha="right",fontsize=8,color=GREY)
ax.text(0.03,3.2,"77 % of\nthe mass\nbelow 11 km",fontsize=8.5,color=BLUE)
ax.set_xlim(0,1); ax.set_ylim(0,30); ax.set_xlabel("$p/p_0$"); ax.set_ylabel("height $z$ (km)"); panel(ax,"(a)")
ax=axs[1]; vals=[("vertical: $\\rho g$ (surface)",1.2*9.81),("cyclone core (illustrative)",0.2),("monsoon-scale gradient (slide 53)",3300/8e6)]
yy=[2,1,0]; cols_=[RED,ORANGE,BLUE]
for y_,(l,v),cc in zip(yy,vals,cols_):
    ax.barh(y_,v,left=1e-5,color=cc,height=0.55); ax.text(v*2.2,y_,f"{v:.3g} Pa/m" if v>1e-3 else f"{v:.1e} Pa/m",va="center",fontsize=8.5)
ax.set_xscale("log"); ax.set_xlim(1e-5,1e4); ax.set_yticks(yy); ax.set_yticklabels([v[0] for v in vals],fontsize=8.5); ax.set_xlabel("pressure-gradient magnitude (Pa m$^{-1}$, log scale)")
ax.annotate("",xy=(3300/8e6,-0.62),xytext=(1.2*9.81,-0.62),arrowprops=dict(arrowstyle="<->",color="k"),annotation_clip=False)
ax.text(np.sqrt(3300/8e6*1.2*9.81),-0.95,"horizontal/vertical $\\approx3.5\\times10^{-5}$",ha="center",fontsize=8.5)
ax.set_ylim(-1.2,2.6); panel(ax,"(b)")
fig.tight_layout(w_pad=2.5); fig.savefig("figs/fig_hydro.pdf"); plt.close()

# ---- atmosphere structure (US Standard Atmosphere 1976 layering)
zb=[0,11,20,32,47,51,71,84.852]; Tb=[288.15,216.65,216.65,228.65,270.65,270.65,214.65,186.946]; Lr=[-6.5,0,1,2.8,0,-2.8,-2.0]
pb=[1013.25]; g=9.80665; R=287.053
for i in range(7):
    dz=(zb[i+1]-zb[i])*1e3
    if Lr[i]==0: pb.append(pb[-1]*np.exp(-g*dz/(R*Tb[i])))
    else: pb.append(pb[-1]*(Tb[i+1]/Tb[i])**(-g/(R*Lr[i]*1e-3)))
zz=np.linspace(0,84.852,800); Tz=np.interp(zz,zb,Tb)
pz=np.interp(zz,zb,np.log(pb)); pz=np.exp(pz)  # log-linear interpolation
fig,axs=plt.subplots(1,3,figsize=(9.6,4.6),gridspec_kw={"width_ratios":[1.15,1,0.95],"wspace":0.28})
ax=axs[0]; ax.plot(Tz,zz,color=RED,lw=2); ax.set_xlim(170,300); ax.set_ylim(0,90)
ax.axvspan(170,300,ymin=15/90,ymax=35/90,color=PURPLE,alpha=0.10,lw=0)
for zh in [11,47,85]: ax.axhline(zh,color=GREY,ls="--",lw=0.7)
ax.text(168,25,"ozone layer\n(15–35 km)",fontsize=8,color=PURPLE,va="center"); ax.text(298,12.5,"tropopause",fontsize=8,ha="right",color=GREY); ax.text(298,48.5,"stratopause",fontsize=8,ha="right",color=GREY); ax.text(298,86,"mesopause",fontsize=8,ha="right",color=GREY)
ax.set_xlabel("temperature $T$ (K)"); ax.set_ylabel("altitude $z$ (km)"); panel(ax,"(a)")
ax=axs[1]; ax.semilogx(pz,zz,color=BLUE,lw=2); ax.set_ylim(0,90); ax.set_xlim(2e-3,1.5e3); ax.set_xlabel("pressure $p$ (hPa)"); ax.set_yticklabels([])
for zh in [11,47,85]: ax.axhline(zh,color=GREY,ls="--",lw=0.7)
ax.text(1.2e3,2,"1013 hPa",fontsize=8,ha="right"); ax.plot([pb[1]],[11],"o",color="k",ms=4); ax.text(pb[1]*0.6,13,"226 hPa",fontsize=8,ha="right"); panel(ax,"(b)")
ax=axs[2]; ax.set_xlim(0,1); ax.set_ylim(0,90); ax.axis("off")
for (a_,b_,n,s) in [(0,11,"troposphere","$T$ falls with height\n($-6.5$ K/km)\nweather; ~80 % of mass"),(11,49,"stratosphere","$T$ rises\n(ozone absorbs UV)\nozone peak ≈ 20–25 km"),(49,85,"mesosphere","$T$ falls again")]:
    ax.plot([0.02,0.02],[a_+0.6,b_-0.6],color="k",lw=1.2); ax.text(0.09,(a_+b_)/2+(3 if n=="troposphere" else 0),n,fontweight="bold",va="center",fontsize=9); ax.text(0.09,(a_+b_)/2-(6 if n=="troposphere" else 6.5 if n=="stratosphere" else 5),s,va="center",fontsize=7.6,color="#333333") if n!="mesosphere" else ax.text(0.09,(a_+b_)/2-5,s,va="center",fontsize=7.6,color="#333333")
ax.text(0.09,89,"thermosphere above",fontsize=8,va="top",style="italic")
fig.savefig("figs/fig_atmos.pdf"); plt.close()

# ---- Mie
m=1.33-1e-9j; xs=np.logspace(-2,2.3,900)
q=np.array([miepython.efficiencies_mx(m,x)[0] for x in xs]) if False else None
try:
    q=np.array([np.atleast_1d(miepython.efficiencies_mx(m,x))[0] for x in xs])
except Exception as e:
    q=np.array([miepython.single_sphere(m,x)[0] for x in xs])
fig,axs=plt.subplots(1,2,figsize=(10.2,4.3),gridspec_kw={"width_ratios":[1,1.2]})
ax=axs[0]; ax.loglog(xs,q,color=BLUE,lw=1.5,label="exact Mie, water ($m=1.33$)")
mm=m.real; ray=(8/3)*xs**4*((mm**2-1)/(mm**2+2))**2; mk=xs<0.6; ax.loglog(xs[mk],ray[mk],color=RED,ls="--",lw=1.2,label="Rayleigh: $\\propto x^4$")
ax.axhline(2,color=GREY,ls=":",lw=1); ax.text(0.011,2.25,"geometric-optics limit $Q\\to2$",fontsize=8,color=GREY)
ax.axvspan(0.01,0.1,color=RED,alpha=0.07,lw=0); ax.axvspan(0.1,50,color=BLUE,alpha=0.05,lw=0); ax.axvspan(50,200,color=GREEN,alpha=0.07,lw=0)
ax.text(0.03,3e-9,"Rayleigh",ha="center",fontsize=8.5); ax.text(2.2,3e-9,"Mie",ha="center",fontsize=8.5); ax.text(100,3e-9,"geometric",ha="center",fontsize=8.5)
ax.set_xlim(0.01,200); ax.set_ylim(1e-10,12); ax.set_xlabel("size parameter $x=2\\pi r/\\lambda$"); ax.set_ylabel("extinction efficiency $K_\\lambda=Q_{\\rm ext}$"); ax.legend(frameon=False,loc="center right",bbox_to_anchor=(1,0.42),fontsize=8); panel(ax,"(a)")
ax=axs[1]; L=np.array([0.1,3e5])
for x_,ls in [(0.1,":"),(1,"-"),(50,"--")]: ax.loglog(L,x_*L/(2*np.pi),color=GREY,ls=ls,lw=1.2 if x_==1 else 1)
for x_,lam_ in [(0.1,300),(1,30),(50,0.3)]:
    ax.text(lam_,x_*lam_/(2*np.pi)*1.25,f"$x={x_:g}$",fontsize=8,color="#333333",ha="left",va="bottom",bbox=dict(fc="white",ec="none",pad=0.5,alpha=0.8))
sz=[(1e-3,"air molecules"),(0.1,"smoke, dust, haze"),(10,"cloud droplets"),(150,"drizzle"),(1500,"raindrops")]
for r_,n in sz: ax.axhline(r_,color="#bbccdd",lw=4,alpha=0.5,zorder=0); ax.text(1.4e5,r_*1.25,n,fontsize=8,ha="right",va="bottom")
for l_,n,cc in [(0.5,"solar",ORANGE),(10,"terrestrial",RED),(1e5,"weather radar",TEAL)]:
    ax.axvline(l_,color=cc,lw=1.2,alpha=0.8); ax.text(l_,1.01,n,transform=ax.get_xaxis_transform(),fontsize=8,ha="center",va="bottom",color=cc)
ax.text(0.15,60,"geometric optics",fontsize=8.5); ax.text(80,40,"Mie",fontsize=8.5); ax.text(1.5e3,0.02,"Rayleigh",fontsize=8.5)
ax.set_xlim(0.1,3e5); ax.set_ylim(4e-4,1.5e4); ax.set_xlabel("wavelength $\\lambda$ ($\\mu$m)"); ax.set_ylabel("particle radius $r$ ($\\mu$m)"); panel(ax,"(b)")
fig.tight_layout(w_pad=2.5); fig.savefig("figs/fig_mie.pdf"); plt.close()

# ---- absorption schematic
lg=np.log10; lam=np.logspace(-1,2,2000); L=lg(lam)
def G(c,w,s): return s*np.exp(-0.5*((L-lg(c))/w)**2)
def sig_(c,w,inv=False): 
    v=1/(1+np.exp(-(L-lg(c))/w)); return 1-v if inv else v
gas={"H$_2$O":np.clip(G(0.94,.012,.4)+G(1.13,.012,.5)+G(1.38,.016,.9)+G(1.87,.02,.9)+G(2.7,.03,1)+G(6.3,.04,1)+sig_(16,.06),0,1),
 "CO$_2$":np.clip(G(2.0,.01,.5)+G(2.7,.015,.7)+G(4.3,.02,1)+G(15,.045,1),0,1),
 "O$_3$":np.clip(sig_(0.31,.03,True)+G(9.6,.025,.9)+G(0.6,.05,.15),0,1),
 "CH$_4$":np.clip(G(3.3,.015,.6)+G(7.7,.025,.8),0,1),
 "N$_2$O":np.clip(G(4.5,.015,.6)+G(7.8,.02,.6)+G(17,.02,.5),0,1),
 "O$_2$":np.clip(G(0.69,.004,.5)+G(0.76,.004,.9),0,1),
 "Rayleigh\nscattering":np.clip((0.35/lam)**4*0.9,0,1)}
tot=1-np.prod([1-v for v in gas.values()],axis=0)
fig=plt.figure(figsize=(9.6,6.6)); gs=fig.add_gridspec(9,1,height_ratios=[2.6]+[1]*7+[1.5],hspace=0.25)
ax0=fig.add_subplot(gs[0])
for T,cc,lab in [(5772,ORANGE,"Sun ($\\approx5772$ K)"),(255,BLUE,"Earth ($\\approx255$ K)")]:
    y=lam*1e-6*planck(lam*1e-6,T); y/=y.max(); ax0.semilogx(lam,y,color=cc,lw=1.8); ax0.fill_between(lam,y,color=cc,alpha=0.15,lw=0)
    ax0.text(0.5 if T>1000 else 22,0.55 if T>1000 else 0.72,lab,color=cc,fontsize=9,ha="center" if T>1000 else "left")
ax0.set_xlim(0.1,100); ax0.set_ylim(0,1.15); ax0.set_ylabel("$\\lambda B_\\lambda$\n(normalised)",fontsize=8.5); ax0.tick_params(bottom=False,labelbottom=False,which="both"); ax0.spines["bottom"].set_visible(False)
axr=[]
for i,(n,v) in enumerate(gas.items()):
    ax=fig.add_subplot(gs[i+1]); ax.set_xscale("log"); ax.set_xlim(0.1,100); ax.fill_between(lam,v,color="#555555",lw=0,alpha=0.8); ax.set_ylim(0,1.05); ax.set_yticks([]); ax.set_ylabel(n,rotation=0,ha="right",va="center",fontsize=9)
    ax.spines["left"].set_visible(False); 
    ax.tick_params(bottom=False,labelbottom=False,which="both"); ax.spines["bottom"].set_visible(False)
    axr.append(ax)
ax=fig.add_subplot(gs[8]); ax.fill_between(lam,tot,color=BLUE,alpha=0.55,lw=0); ax.axvspan(8,13,color=GREEN,alpha=0.25,lw=0)
ax.text(10.2,0.5,"atmospheric\nwindow",ha="center",va="center",fontsize=8.5,color="#0b4d25",bbox=dict(fc="white",ec="none",alpha=0.75,pad=1)); ax.set_ylim(0,1.05); ax.set_yticks([]); ax.spines["left"].set_visible(False)
ax.set_ylabel("total",rotation=0,ha="right",va="center",fontsize=9)
axr[-1].set_xlabel("")
ax.set_xscale("log"); ax.set_xlim(0.1,100); ax.set_xticks([0.1,0.2,0.5,1,2,5,10,20,50,100]); ax.set_xticklabels(["0.1","0.2","0.5","1","2","5","10","20","50","100"]); ax.set_xlabel("wavelength ($\\mu$m)")
fig.savefig("figs/fig_absorb.pdf"); plt.close()

# ---- two-layer
Te=((0.7*S0/4)/sig)**.25; eps=np.linspace(0,1,200); Tsr=Te*(1-eps/2)**-.25
fig,axs=plt.subplots(1,2,figsize=(9.4,3.8),gridspec_kw={"width_ratios":[1.2,1]})
ax=axs[0]; ax.plot(eps,Tsr,color=RED,lw=2,label="surface $T_s$"); ax.plot(eps,Tsr*2**-.25,color=BLUE,lw=2,label="atmosphere $T_a=T_s/2^{1/4}$")
ax.axhline(Te,color=GREY,ls="--",lw=0.9); ax.text(0.02,Te-6,"$T_e=254.6$ K (no atmosphere)",fontsize=8,color=GREY,va="top")
e_E=2*(1-(Te/288)**4); ax.plot([e_E],[288],"o",color="k"); ax.annotate(f"Earth: $\\epsilon\\approx{e_E:.2f}$ gives 288 K",xy=(e_E,288),xytext=(0.03,300),fontsize=8.5,arrowprops=dict(arrowstyle="->",color=GREY))
ax.plot([1],[Te*2**.25],"o",color="k"); ax.text(0.98,Te*2**.25+4,"$\\epsilon=1$: 302.7 K",fontsize=8.5,ha="right")
ax.set_xlabel("atmospheric emissivity $\\epsilon$"); ax.set_ylabel("temperature (K)"); ax.set_ylim(200,320); ax.legend(frameon=False,loc="lower right",fontsize=8.5); panel(ax,"(a)")
ax=axs[1]; Ns=np.arange(0,6); TN=Te*(Ns+1)**.25; ax.bar(Ns,TN,color=[GREY]+[RED]*5,width=0.65)
for n_,t_ in zip(Ns,TN): ax.text(n_,t_+5,f"{t_:.0f}",ha="center",fontsize=8.5)
ax.axhline(288,color="k",ls="--",lw=0.9); ax.text(-0.4,293,"observed 288 K",fontsize=8,ha="left",va="bottom")
ax.set_xlabel("number $N$ of fully absorbing layers"); ax.set_ylabel("surface temperature (K)"); ax.set_ylim(0,420); panel(ax,"(b)")
fig.tight_layout(w_pad=2.5); fig.savefig("figs/fig_twolayer.pdf"); plt.close()

# ---- diurnal
C=7.5e5; a=0.31; om=2*np.pi/86400
sol=solve_ivp(lambda t,T:((1-a)*S0*max(np.sin(om*t),0)-sig*T**4)/C,[0,8*86400],[255],max_step=150,rtol=1e-9,atol=1e-9,dense_output=True)
t=np.linspace(0,6*86400,4000); T=sol.sol(t)[0]
fig=plt.figure(figsize=(9.8,6.0)); gs=fig.add_gridspec(2,2,height_ratios=[1,1.05],hspace=0.42,wspace=0.28)
ax=fig.add_subplot(gs[0,:]); ax.plot(t/86400,T,color=RED,lw=1.8); ax.axhline(255,color=GREY,ls=":",lw=0.8); ax.text(5.98,256.5,"initial condition $T(0)=255$ K",fontsize=8,ha="right",color=GREY)
ax.axhline(269.4,color=BLUE,ls="--",lw=0.9); ax.text(5.98,270.5,"$T$ from mean flux, $\\langle F\\rangle=\\sigma T^4$: 269.4 K",fontsize=8,ha="right",color=BLUE)
ax.set_xlabel("time since sunrise on day 0 (days)"); ax.set_ylabel("$T$ (K)"); ax.set_xlim(0,6); panel(ax,"(a)")
td=np.linspace(5*86400,6*86400,1500); Td=sol.sol(td)[0]; hh=(td-5*86400)/3600
SW=(1-a)*S0*np.maximum(np.sin(om*td),0); LW=sig*Td**4
ax=fig.add_subplot(gs[1,0]); ax.plot(hh,SW,color=BLUE,lw=2,label="absorbed SW"); ax.plot(hh,LW,color=RED,lw=2,label="emitted $\\sigma T^4$")
ax.fill_between(hh,SW,LW,where=SW>LW,color=BLUE,alpha=0.12,lw=0); ax.fill_between(hh,SW,LW,where=SW<LW,color=RED,alpha=0.12,lw=0)
ip=np.argmax(Td); ax.axvline(hh[ip],color="k",ls=":",lw=1); ax.text(hh[ip]+0.3,560,f"$T_{{max}}$ at\n{hh[ip]:.1f} h",fontsize=8.5)
ax.set_xlim(0,24); ax.set_xticks([0,6,12,18,24]); ax.set_xlabel("hours after sunrise"); ax.set_ylabel("flux (W m$^{-2}$)"); ax.legend(frameon=False,loc="upper right",fontsize=8.5); panel(ax,"(b)")
ax=fig.add_subplot(gs[1,1]); ax.plot(hh,Td,color=RED,lw=2); ax.plot([hh[ip]],[Td[ip]],"o",color="k"); im=np.argmin(Td); ax.plot([hh[im]],[Td[im]],"o",color="k")
ax.text(hh[ip]-0.5,Td[ip]+0.8,f"{Td[ip]:.1f} K",ha="right",fontsize=8.5); ax.text(hh[im]+0.6,Td[im]-2.2,f"{Td[im]:.1f} K",fontsize=8.5)
ax.set_xlim(0,24); ax.set_xticks([0,6,12,18,24]); ax.set_xlabel("hours after sunrise"); ax.set_ylabel("$T$ (K)"); panel(ax,"(c)")
fig.savefig("figs/fig_diurnal.pdf"); plt.close()
print("D done", hh[ip], Td[ip], Td[im], hh[im])
