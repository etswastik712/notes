import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse, Rectangle
plt.rcParams.update({
 "font.family":"serif","font.serif":["DejaVu Serif"],"mathtext.fontset":"cm",
 "font.size":9.5,"axes.labelsize":10,"axes.titlesize":10,"legend.fontsize":8.5,
 "axes.spines.top":False,"axes.spines.right":False,"axes.linewidth":0.8,
 "figure.dpi":150,"savefig.bbox":"tight","savefig.pad_inches":0.05,"pdf.fonttype":42,
 "xtick.direction":"out","ytick.direction":"out","axes.grid":False})
h=6.62607015e-34; c=2.99792458e8; kB=1.380649e-23
sig=5.670374419e-8; c2=h*c/kB
S0=1361.0
BLUE="#1f4e8c"; RED="#c0392b"; GREEN="#1c7848"; ORANGE="#d9822b"; PURPLE="#6c3f9a"; GREY="#666666"; TEAL="#158a94"
def planck(lam,T):
    x=c2/(lam*T); 
    with np.errstate(over="ignore"):
        return 2*h*c**2/lam**5/np.expm1(x)
def panel(ax,s):
    ax.text(-0.02,1.03,s,transform=ax.transAxes,fontweight="bold",fontsize=11,va="bottom",ha="right")
