from figcommon import *
from scipy.optimize import brentq
Te=((0.7*S0/4)/sig)**.25; SWa=0.7*S0/4
# ---- balance
T=np.linspace(200,300,400)
fig,axs=plt.subplots(1,2,figsize=(9.6,3.8))
ax=axs[0]; ax.plot(T,sig*T**4,color=RED,lw=2,label="$\\sigma T^4$ (outgoing longwave)"); ax.axhline(SWa,color=BLUE,lw=2,label="$(1-\\alpha)S/4$ (absorbed shortwave)")
ax.plot([Te],[SWa],"o",color="k"); ax.annotate("$T_e=254.6$ K,  238.2 W m$^{-2}$",xy=(Te,SWa),xytext=(214,335),fontsize=8.5,arrowprops=dict(arrowstyle="->",color=GREY))
for Tp in [240,276]: ax.annotate("",xy=(Tp,SWa),xytext=(Tp,sig*Tp**4),arrowprops=dict(arrowstyle="<->",color=GREY,lw=0.9))
ax.text(280,150,"$T>T_e$:\nOLR $>$ absorbed\n$\\Rightarrow$ cools",fontsize=8,ha="left",va="center")
ax.text(201,175,"$T<T_e$:\nOLR $<$ absorbed\n$\\Rightarrow$ warms",fontsize=8,ha="left",va="center")
ax.set_xlabel("$T_s$ (K)"); ax.set_ylabel("flux (W m$^{-2}$)"); ax.legend(frameon=False,loc="upper left",fontsize=8); ax.set_ylim(80,470); panel(ax,"(a)")
ax=axs[1]; N=SWa-sig*T**4; ax.plot(T,N,color="k",lw=2); ax.axhline(0,color=GREY,lw=0.7)
ax.fill_between(T,N,0,where=N>0,color=RED,alpha=0.18,lw=0); ax.fill_between(T,N,0,where=N<0,color=BLUE,alpha=0.18,lw=0)
ax.plot([Te],[0],"o",color="k",ms=7); ax.text(Te+3,45,"stable\nsteady state",fontsize=8.5)
for x0,x1,yy in [(210,240,32),(295,268,-32)]: ax.annotate("",xy=(x1,yy),xytext=(x0,yy),arrowprops=dict(arrowstyle="-|>",color="k",lw=1.4))
ax.text(226,58,"net gain $\\Rightarrow$ $T$ rises",fontsize=8,ha="center"); ax.text(281,-85,"net loss $\\Rightarrow$ $T$ falls",fontsize=8,ha="center")
ax.set_xlabel("$T_s$ (K)"); ax.set_ylabel("net flux $N=$ SW$_{\\rm abs}-\\sigma T_s^4$ (W m$^{-2}$)"); panel(ax,"(b)")
fig.tight_layout(w_pad=2.5); fig.savefig("figs/fig_balance.pdf"); plt.close()

# ---- planets
names=["Mercury","Venus","Earth","Mars","Jupiter","Saturn"]; dist=[0.387,0.723,1.0,1.524,5.203,9.537]; alb=[0.09,0.76,0.31,0.25,0.5,0.34]; obs=[440,737,288,210,165,134]
mod=[((1-a)*S0/d**2/(4*sig))**.25 for a,d in zip(alb,dist)]
off={"Mercury":(-14,14,"right"),"Venus":(10,-4,"left"),"Earth":(12,-14,"left"),"Mars":(8,-16,"left"),"Jupiter":(10,10,"left"),"Saturn":(8,-14,"left")}
fig,axs=plt.subplots(1,2,figsize=(9.6,3.9),gridspec_kw={"width_ratios":[1.15,1]})
ax=axs[0]; ax.plot([50,800],[50,800],color=GREY,lw=0.9,ls="--")
for n,m_,o in zip(names,mod,obs):
    ax.plot([m_],[o],"o",color=ORANGE,ms=6); dx,dy,ha=off[n]; ax.annotate(n,xy=(m_,o),xytext=(dx,dy),textcoords="offset points",fontsize=8.5,ha=ha)
ax.text(560,520,"model = observed",rotation=0,fontsize=8,color=GREY)
ax.set_xlim(50,600); ax.set_ylim(50,800); ax.set_xlabel("model temperature (K)"); ax.set_ylabel("observed mean temperature (K)"); panel(ax,"(a)")
ax=axs[1]; res=[o-m_ for o,m_ in zip(obs,mod)]; y=np.arange(6)[::-1]
ax.barh(y,res,color=[RED if r>15 else GREY for r in res]); ax.set_yticks(y); ax.set_yticklabels(names); ax.axvline(0,color="k",lw=0.7)
for yy,r in zip(y,res): ax.text(r+(10 if r>=0 else -10),yy,f"{r:+.0f} K",va="center",ha="left" if r>=0 else "right",fontsize=8.5)
ax.set_xlim(-60,600); ax.set_xlabel("observed $-$ model (K)"); panel(ax,"(b)")
fig.tight_layout(w_pad=2.5); fig.savefig("figs/fig_planets.pdf"); plt.close()
print("model",[round(m_,1) for m_ in mod])

# ---- feedback
fig,axs=plt.subplots(1,2,figsize=(9.6,3.8))
ax=axs[0]; f=np.linspace(-1.2,0.985,600); ax.plot(f,1/(1-f),color=BLUE,lw=2)
ax.axvspan(1,1.4,color=RED,alpha=0.12,lw=0); ax.axvline(1,color=RED,ls="--",lw=1)
ax.text(1.03,6.2,"$\\sum f_i\\geq1$:\nunstable,\nno steady\nresponse",color=RED,fontsize=8,va="center")
for fv in [0.5,0.9,-1.0]: ax.plot([fv],[1/(1-fv)],"o",color="k",ms=4); 
ax.annotate("$f=0.5$: $\\Lambda=2\\Lambda_P$",xy=(0.5,2),xytext=(-0.55,3.8),fontsize=8.5,arrowprops=dict(arrowstyle="->",color=GREY))
ax.annotate("$f=0.9$: $\\Lambda=10\\Lambda_P$",xy=(0.9,10),xytext=(-0.6,8.5),fontsize=8.5,arrowprops=dict(arrowstyle="->",color=GREY))
ax.annotate("$f=-1$: $\\Lambda=\\Lambda_P/2$",xy=(-1,0.5),xytext=(-0.6,1.7),fontsize=8.5,arrowprops=dict(arrowstyle="->",color=GREY))
ax.set_xlim(-1.2,1.4); ax.set_ylim(0,12); ax.set_xlabel("total feedback factor $f=\\sum_i f_i$"); ax.set_ylabel("$\\Lambda/\\Lambda_P=1/(1-f)$"); panel(ax,"(a)")
ax=axs[1]; n=np.arange(0,11)
for fv,cc in [(0.5,GREEN),(0.9,ORANGE),(1.0,RED),(1.1,PURPLE)]:
    cum=np.cumsum(fv**n); ax.plot(n,cum,"o-",color=cc,ms=3.5,lw=1.4); ax.text(10.3,min(cum[-1],17.0)+(0.9 if fv==0.5 else 0),f"$f={fv}$",color=cc,fontsize=8.5,va="center")
ax.set_ylim(0,18); ax.set_xlim(0,12); ax.set_xlabel("feedback iteration $n$"); ax.set_ylabel("$\\Delta T_n/\\Delta T_0=\\sum_{k=0}^{n}f^k$"); panel(ax,"(b)")
fig.tight_layout(w_pad=2.5); fig.savefig("figs/fig_feedback.pdf"); plt.close()

# ---- albedo & multiple steady states
def alpha(T): return np.where(T<253,0.7,np.where(T<=293,0.7-0.5*(T-253)/40,0.2))
fac=0.6
def roots(s,fac=fac):
    Tg=np.linspace(170,360,19001); v=(1-alpha(Tg))*S0*s/4-fac*sig*Tg**4
    return [brentq(lambda T:(1-alpha(T))*S0*s/4-fac*sig*T**4,Tg[i],Tg[i+1]) for i in range(len(Tg)-1) if v[i]*v[i+1]<0]
r=roots(1.0); print("roots",r)
def stable(T,s):
    dSW=(S0*s/4)*0.0125 if 253<T<293 else 0; return 4*fac*sig*T**3-dSW>0
fig=plt.figure(figsize=(11,3.9)); gs=fig.add_gridspec(1,3,width_ratios=[0.8,1.15,1.1])
ax=fig.add_subplot(gs[0]); Tt=np.linspace(200,320,500); ax.plot(Tt,alpha(Tt),color=ORANGE,lw=2)
ax.text(205,0.725,"ice/snow-covered: $\\alpha=0.7$",fontsize=8,va="bottom"); ax.text(298,0.215,"ice-free: $\\alpha=0.2$",fontsize=8,ha="right",va="bottom")
ax.text(262,0.5,"linear ramp\n$\\mathrm{d}\\alpha/\\mathrm{d}T=-0.0125$ K$^{-1}$",fontsize=8,ha="left",va="center"); ax.set_ylim(0.1,0.82); ax.set_xlim(200,320)
ax.set_xlabel("$T_s$ (K)"); ax.set_ylabel("albedo $\\alpha(T_s)$"); panel(ax,"(a)")
ax=fig.add_subplot(gs[1]); T2=np.linspace(200,330,600)
ax.plot(T2,(1-alpha(T2))*S0/4,color=BLUE,lw=2,label="SW$_{\\rm net}=(1-\\alpha)S/4$"); ax.plot(T2,fac*sig*T2**4,color=RED,lw=2,label="LW$_{\\rm out}=0.6\\,\\sigma T^4$")
ax.plot(T2,sig*T2**4,color=GREY,lw=1,ls=":",label="$\\sigma T^4$ (no atmosphere)")
lab={0:("snowball\n234 K",(-6,22)),1:("unstable\n274 K",(-52,18)),2:("ice-free\n299 K",(6,-40))}
for i,Tr in enumerate(r):
    st=stable(Tr,1.0); ax.plot([Tr],[(1-alpha(Tr))*S0/4],"o",ms=8,mfc=(RED if st else "white"),mec="k",zorder=5)
    t,(dx,dy)=lab[i]; ax.annotate(t,xy=(Tr,(1-alpha(Tr))*S0/4),xytext=(dx,dy),textcoords="offset points",fontsize=8,ha="center")
ax.set_ylim(60,400); ax.set_xlim(200,330); ax.set_xlabel("$T_s$ (K)"); ax.set_ylabel("flux (W m$^{-2}$)"); ax.legend(frameon=False,loc="upper left",fontsize=7.6); panel(ax,"(b)")
ax=fig.add_subplot(gs[2]); ss=np.linspace(0.55,1.45,1800)
for s in ss:
    for Tr in roots(s):
        ax.plot([s],[Tr],".",color=(RED if stable(Tr,s) else GREY),ms=1.6 if stable(Tr,s) else 1.0)
# fold points
def nroots(s): return len(roots(s))
lo,hi=0.55,1.0
grid=np.linspace(0.55,1.45,900); n_=[nroots(s) for s in grid]
folds=[grid[i] for i in range(1,len(grid)) if n_[i]!=n_[i-1]]; print("folds",folds,n_[0],n_[-1])
ax.axvline(1.0,color=GREY,lw=0.7,ls="--"); ax.text(1.01,325,"present\n$S=S_0$",fontsize=7.8,ha="left")
ax.annotate("fold at $S/S_0\\approx0.92$:\nice-free state vanishes",xy=(folds[0],293),xytext=(0.58,318),fontsize=7.8,arrowprops=dict(arrowstyle="->",color=GREY))
ax.annotate("fold at $S/S_0\\approx1.37$:\nsnowball state vanishes",xy=(folds[1],253),xytext=(1.03,215),fontsize=7.8,arrowprops=dict(arrowstyle="->",color=GREY))
ax.set_xlabel("$S/S_0$"); ax.set_ylabel("steady-state $T_s$ (K)"); ax.set_xlim(0.55,1.45); ax.set_ylim(190,340)
ax.plot([],[],".",color=RED,label="stable"); ax.plot([],[],".",color=GREY,label="unstable"); ax.legend(frameon=False,loc="center left",bbox_to_anchor=(0.0,0.6),fontsize=8,markerscale=3)
np.save("folds.npy",np.array(folds)); panel(ax,"(c)")
fig.tight_layout(w_pad=2.0); fig.savefig("figs/fig_albedo.pdf"); plt.close(); print("C done")
