from figcommon import *
# ---------- Taylor
t=np.linspace(0,6,600)
a,w,b=1.6,1.0,0.25
x=lambda t:a*np.sin(w*t)+b*t
def taylor(t,n):
    # Taylor polynomial of a sin(w t)+ b t about 0 up to order n
    out=b*t if n>=1 else 0*t
    from math import factorial
    for k in range(1,n+1,2):
        out=out+a*((-1)**((k-1)//2))*(w*t)**k/factorial(k) if k!=1 else out+a*w*t
    return out
fig,ax=plt.subplots(figsize=(7.2,3.9))
ax.plot(t,x(t),color="k",lw=2.2,label="true trajectory $x(t)$")
cols=[BLUE,GREEN,ORANGE,RED]
for n,cc in zip([1,3,5,9],cols):
    ax.plot(t,taylor(t,n),color=cc,lw=1.3,label=f"Taylor polynomial, order {n}")
ax.set_ylim(-4,6); ax.set_xlim(0,6)
ax.axvline(0,color=GREY,lw=0.6,ls=":")
ax.annotate("$t_0$: state and\nall derivatives known",xy=(0,0),xytext=(0.35,-3.0),fontsize=8.5,arrowprops=dict(arrowstyle="->",color=GREY))
ax.set_xlabel("time $t-t_0$ (arbitrary units)"); ax.set_ylabel("position $x$")
ax.legend(loc="upper left",frameon=False,ncol=1)
fig.savefig("figs/fig_taylor.pdf"); plt.close()

# ---------- Stommel
fig,ax=plt.subplots(figsize=(7.6,5.6))
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(1e-1,1e8); ax.set_ylim(1e-1,1e10)
Lg=np.array([1e-1,1e8])
for U in [1,10,100]: ax.plot(Lg,Lg/U,color=GREY,lw=0.7,ls="--",zorder=0)
for U,yl in [(1,1e8),(10,1e7),(100,1e6)]: ax.text(1.3e8,yl,f"$U={U}$ m/s",color=GREY,fontsize=7.5,va="center",ha="left",clip_on=False)
inline=[("Turbulence",0.9,1.1,1.0,1.0,GREEN),("Thermals",2.5,2.6,0.75,0.5,GREEN),("Tornadoes",3.0,3.4,0.55,0.4,ORANGE),("Thunderstorms",3.85,3.9,0.75,0.5,ORANGE)]
side=[("Fronts, squall lines",4.8,4.5,0.5,0.25,BLUE),("Cloud clusters",5.5,5.0,0.5,0.25,BLUE),("Tropical cyclones",5.9,5.6,0.45,0.25,BLUE),("Planetary waves",7.0,6.25,0.5,0.3,PURPLE),("Intraseasonal (MJO)",7.3,6.85,0.35,0.22,PURPLE),("Seasonal cycle",7.3,7.5,0.35,0.2,PURPLE),("ENSO",7.3,8.0,0.35,0.2,PURPLE),("Climate variation",7.4,9.0,0.4,0.5,PURPLE)]
th=np.linspace(0,2*np.pi,200)
for lab,lx,ly,wx,wy,cc in inline+side:
    X=10**(lx+wx*np.cos(th)); Y=10**(ly+wy*np.sin(th)); ax.fill(X,Y,color=cc,alpha=0.18,lw=0); ax.plot(X,Y,color=cc,lw=1.0)
for lab,lx,ly,wx,wy,cc in inline: ax.text(10**lx,10**ly,lab,ha="center",va="center",fontsize=7.8)
for lab,lx,ly,wx,wy,cc in side:
    ax.plot([10**3.1,10**(lx-wx)],[10**ly]*2,color=cc,lw=0.6); ax.text(10**3.0,10**ly,lab,ha="right",va="center",fontsize=7.8)
ax.set_xlabel("horizontal length scale $L$ (m)"); ax.set_ylabel("time scale $t$ (s)")
for s,lab in [(60,"1 min"),(3600,"1 h"),(86400,"1 day"),(6.048e5,"1 week"),(2.63e6,"1 month"),(3.156e7,"1 year"),(3.156e9,"100 yr")]:
    ax.axhline(s,color="#e2e2e2",lw=0.5,zorder=0); ax.text(1.15e-1,s*1.12,lab,fontsize=7.2,color=GREY,va="bottom")
ax.text(1e1,0.13,"micro",color=GREY,fontsize=8,ha="center"); ax.text(10**4.0,0.13,"meso",color=GREY,fontsize=8,ha="center"); ax.text(10**6.9,0.13,"synoptic / planetary",color=GREY,fontsize=8,ha="center")
ax.axvline(2e4,color=GREY,lw=0.6,ls=":"); ax.axvline(2e6,color=GREY,lw=0.6,ls=":")
fig.savefig("figs/fig_stommel.pdf"); plt.close()

# ---------- synthetic time series
rng=np.random.default_rng(3)
N=10*365*24; th=np.arange(N)/24.0  # days
ann=4.0*np.cos(2*np.pi*(th-130)/365.25); dia=5.5*np.cos(2*np.pi*((th%1)-15/24))
tr=0.05*th/365.25
nz=np.zeros(N); e=rng.normal(0,1.0,N)
for i in range(1,N): nz[i]=0.985*nz[i-1]+e[i]*1.0
nz=nz/nz.std()*1.4
T=25+ann+dia+tr+nz
fig,axs=plt.subplots(2,2,figsize=(9.2,6.4))
ax=axs[0,0]; m=(th>=200)&(th<214); ax.plot(th[m]-200,T[m],color=BLUE,lw=0.8)
ax.set_xlabel("time (days)"); ax.set_ylabel("temperature ($^\\circ$C)"); panel(ax,"(a)")
ax.set_title("14 days of hourly data",fontsize=9)
ax=axs[0,1]; Td=T.reshape(-1,24).mean(1); ax.plot(np.arange(Td.size)/365.25,Td,color=GREY,lw=0.4,label="daily mean")
run=np.convolve(Td,np.ones(365)/365,mode="valid"); ax.plot((np.arange(run.size)+182)/365.25,run,color=RED,lw=1.6,label="365-day running mean")
ax.set_xlabel("time (years)"); ax.set_ylabel("temperature ($^\\circ$C)"); ax.legend(frameon=False,loc="upper left",ncol=2,fontsize=7.8); ax.set_ylim(15,38); panel(ax,"(b)")
ax.set_title("10 years of daily means",fontsize=9)
ax=axs[1,0]; hr=(th%1)*24; H=T.reshape(-1,24); mu=H.mean(0); sd=H.std(0)
# remove seasonal for the fold? keep raw fold
ax.fill_between(np.arange(24),mu-sd,mu+sd,color=BLUE,alpha=0.2,lw=0,label="$\\pm1$ std. dev."); ax.plot(np.arange(24),mu,color=BLUE,lw=2,label="mean over all days")
ax.set_xlabel("hour of day"); ax.set_ylabel("temperature ($^\\circ$C)"); ax.legend(frameon=False,loc="upper left"); ax.set_xlim(0,23); panel(ax,"(c)")
ax.set_title("folding modulo 24 h",fontsize=9)
ax=axs[1,1]
Tz=T-T.mean(); F=np.fft.rfft(Tz*np.hanning(N)); fr=np.fft.rfftfreq(N,d=1/24.0)  # cycles/day
amp=2*np.abs(F)/np.hanning(N).sum()
ax.loglog(fr[1:],amp[1:],color=PURPLE,lw=0.8)
ax.set_xlabel("frequency (cycles per day)"); ax.set_ylabel("amplitude (K)"); ax.set_ylim(3e-4,200); ax.set_xlim(1e-4,12)
ax.annotate("annual: 1/365 d$^{-1}$",xy=(1/365.25,4.2),xytext=(1e-3,40),fontsize=8,arrowprops=dict(arrowstyle="->",color=GREY),ha="center")
ax.annotate("diurnal: 1 d$^{-1}$",xy=(1,5.6),xytext=(0.25,40),fontsize=8,arrowprops=dict(arrowstyle="->",color=GREY),ha="center")
ax.set_title("Fourier amplitude spectrum",fontsize=9); panel(ax,"(d)")
fig.tight_layout(w_pad=2.2,h_pad=2.0)
fig.savefig("figs/fig_synth.pdf"); plt.close()
print("A done")
