Landscapes and Their Evolution -- notes source
================================================

Compile with (pdflatex, run twice for the table of contents):
    pdflatex main.tex
    pdflatex main.tex

Files:
    main.tex            top-level document (\input's everything below)
    preamble.tex         packages, colours, tcolorbox box definitions, macros
    p0_front.tex          front matter: box key, notation, symbol table, glossary
    p1_foundations.tex    Part I  -- landscapes as systems; mechanics/maths toolkit
    p2_mapping.tex         Part II -- DEMs, terrain analysis, map projections
    p3_planet.tex          Part III -- planetary shape, maximum topography
    p4_isostasy.tex        Part IV -- isostasy
    p5_tectonics.tex       Part V  -- plate tectonics, earthquakes, folds/flexure
    p6_weathering.tex      Part VI -- weathering and regolith
    p7_hillslope.tex       Part VII -- hillslope transport and landslides
    p8_glacier.tex         Part VIII -- glaciers, deposits, isostatic rebound
    p9_postms.tex          Part IX -- fluvial and aeolian (post-mid-sem, not in slides)
    p10_problems.tex       Part X -- worked practice problems
    d_erfc.dat, d_ocean.dat, d_riverprofile.dat
                           small data tables plotted by pgfplots (regenerate with
                           the snippet below if you need to edit the underlying
                           numbers)

Requires a standard TeX Live install with: tikz, pgfplots (compat=1.16),
tcolorbox (with the "most" library), booktabs, tabularx, longtable, multirow,
mathtools, bm, microtype, fancyhdr, geometry, xcolor (dvipsnames), enumitem,
caption, hyperref.

Regenerating the .dat files (Python 3, needs numpy):

    import math, numpy as np
    def w(name, cols, rows):
        with open(name,'w') as f:
            f.write(' '.join(cols)+'\n')
            for r in rows: f.write(' '.join(f'{v:.6g}' for v in r)+'\n')
    # d_erfc.dat: three erfc(x/2sqrt(Dt)) curves at Dt = 1, 4, 16
    xs = np.linspace(0,12,121)
    w('d_erfc.dat', ['x','y1','y2','y3'],
      [(x, math.erfc(x/2), math.erfc(x/4), math.erfc(x/8)) for x in xs])
    # d_ocean.dat and d_riverprofile.dat: see the corresponding derivations
    # in p4_isostasy.tex (S7.4) and p9_postms.tex (S16.2) for the formulas.
